CREATE TABLE TIPOENTREGA
(
    ID          BIGSERIAL NOT NULL
        CONSTRAINT TIPOENTREGA_PKEY
            PRIMARY KEY,
    TIPOENTREGA VARCHAR(255)
);

ALTER TABLE TIPOENTREGA
    OWNER TO POSTGRES;

INSERT INTO public.tipoentrega (id, tipoentrega) VALUES (1, 'Retirar na loja');
INSERT INTO public.tipoentrega (id, tipoentrega) VALUES (2, 'Motoboy');
INSERT INTO public.tipoentrega (id, tipoentrega) VALUES (4, 'Transportadora Sapitcho');
INSERT INTO public.tipoentrega (id, tipoentrega) VALUES (3, 'Correios');