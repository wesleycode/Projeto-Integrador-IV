CREATE TABLE ENDERECO
(
    ID          BIGSERIAL NOT NULL
        CONSTRAINT ENDERECO_PKEY
            PRIMARY KEY,
    BAIRRO      VARCHAR(255),
    CEP         VARCHAR(255),
    COMPLEMENTO VARCHAR(255),
    NUMERO      INTEGER   NOT NULL,
    RUA         VARCHAR(255),
    CIDADE_ID   BIGINT
        CONSTRAINT FKSQ6FA88CLRYV3UQSBGVVA4FNE
            REFERENCES CIDADE
);

ALTER TABLE ENDERECO
    OWNER TO POSTGRES;

INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (1, 'Campina da Barra', '81250-280', 'Casa', 1170, 'Rua Malva', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (2, 'Fazenda Velha', '83720-210', 'Casa', 174, 'Rua São Judas Tadeu', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (3, 'Fazenda Velha', '83703-410', 'Casa', 601, 'R. Alexandre Wisocki', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (4, 'Fazenda Velha', '83703-320', 'Casa', 401, 'R. Antônio Cândido Nascimento', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (5, 'Fazenda Velha', '83703-340', 'Casa', 390, 'R. Jose Huttner', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (6, 'Fazenda Velha', '83703-410', 'Casa', 462, 'R. José Huttner', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (7, 'Iguaçu', '83701-627', 'Edifício', 309, 'R. Rio de Janeiro', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (8, 'Iguaçu', '83701-250', 'Casa', 1207, 'Av. Brasil', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (9, 'Iguaçu', '83701-205', 'Casa', 460, 'R. Espírito Santo', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (10, 'Iguaçu', '83701-210', 'Casa', 147, 'R. Fernando de Noronha', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (11, 'Iguaçu', '83701-010', 'Casa', 158, 'R. Paraíba', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (12, 'Capela Velha', '83706-190', 'Casa', 1130, 'R. Tucano', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (13, 'Capela Velha', '83706-220', 'Casa', 735, 'R. Tesoureiro', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (14, 'Capela Velha', '83706-070', 'Casa', 1068, 'R. Maracanā', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (15, 'Capela Velha', '83706-270', 'Casa', 1285, 'R. Pomba', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (16, 'Capela Velha', '83706-060', 'Casa', 1280, 'Rua Pinguim', 2806);
INSERT INTO public.endereco (id, bairro, cep, complemento, numero, rua, cidade_id) VALUES (17, 'Capela Velha', '83706-160', 'Casa', 1142, 'R. Arapongas', 2806);