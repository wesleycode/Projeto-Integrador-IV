CREATE TABLE FORMAPAGAMENTO
(
    ID             BIGSERIAL NOT NULL
        CONSTRAINT FORMAPAGAMENTO_PKEY
            PRIMARY KEY,
    FORMAPAGAMENTO VARCHAR(255)
);

ALTER TABLE FORMAPAGAMENTO
    OWNER TO POSTGRES;

INSERT INTO public.formapagamento (id, formapagamento) VALUES (1, 'Débito Automático');
INSERT INTO public.formapagamento (id, formapagamento) VALUES (2, 'Cartão de Crédito');
INSERT INTO public.formapagamento (id, formapagamento) VALUES (3, 'Boleto Bancário');