CREATE TABLE FORNECEDOR
(
    ID         BIGINT NOT NULL
        CONSTRAINT FORNECEDOR_PKEY
            PRIMARY KEY,
    FORNECEDOR VARCHAR(255),
    HYPERLINK  VARCHAR(255)
);

ALTER TABLE FORNECEDOR
    OWNER TO POSTGRES;

INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (1, 'Hyper X', 'https://www.hyperxgaming.com');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (2, 'XPG', 'https://www.xpg.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (3, 'Corsair', 'https://www.corsair.com/pt/pt/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (4, 'HP', 'https://store.hp.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (5, 'Kingston', 'https://www.kingston.com/br');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (6, 'Intel', 'https://www.intel.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (7, 'Seagate', 'https://www.seagate.com/br/pt/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (8, 'TOMAHAWK ', 'https://www.kabum.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (9, 'Fortrek', 'https://fortrek.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (10, 'EVGA', 'https://www.evga.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (11, 'One Power', 'https://www.kabum.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (12, 'Raptor', 'https://www.kabum.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (13, 'LENOVO', 'https://www.lenovo.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (14, 'WD', 'https://www.kabum.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (15, 'Cooler Master', 'https://www.coolermaster.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (16, 'Gamdias', 'https://www.gamdias.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (17, 'Rise Mode', 'https://www.risemode.nz/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (18, 'DeepCool', 'https://www.deepcool.com/pt/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (19, 'DARKFLASH', 'https://darkflashtech.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (20, 'Bluecase', 'http://www.bluecase.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (21, 'AOC', 'http://www.aoc.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (22, 'PCTOP', 'https://www.kabum.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (23, 'Lg', 'https://www.lg.com/br');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (24, 'ACER', 'https://www.acer.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (25, 'Agon', 'https://www.kabum.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (26, 'Samsung', 'https://www.samsung.com/br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (27, 'asus', 'https://www.asus.com/br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (28, 'Creative', 'https://www.kabum.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (29, 'GV', 'http://www.gvbrasil.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (30, 'Gigabyte', 'https://www.gigabyte.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (31, 'Galax', 'https://www.kabum.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (32, 'MSI', 'https://www.msi.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (33, 'PowerColor', 'https://www.powercolor.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (34, 'Aorus', 'https://www.aorus.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (35, 'Norton', 'https://br.norton.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (36, 'Kaspersky', 'https://www.kaspersky.com.br/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (37, 'PNY', 'https://www.pny.com/');
INSERT INTO public.fornecedor (id, fornecedor, hyperlink) VALUES (38, 'VAIO', 'https://www.br.vaio.com/');