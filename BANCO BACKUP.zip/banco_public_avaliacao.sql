CREATE TABLE AVALIACAO
(
    ID          BIGSERIAL NOT NULL
        CONSTRAINT AVALIACAO_PKEY
            PRIMARY KEY,
    COMENTARIO  VARCHAR(255),
    DATAPOSTADO TIMESTAMP,
    NOTA        INTEGER   NOT NULL,
    PESSOA_ID   BIGINT
        CONSTRAINT FKMFPSYJ33H70G041Y9TEYJ4CEQ
            REFERENCES PESSOA,
    PRODUTO_ID  BIGINT
        CONSTRAINT FKOEE0TQU85KD0EF8VVCI3JO96F
            REFERENCES PRODUTO
);

ALTER TABLE AVALIACAO
    OWNER TO POSTGRES;

INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (1, 'melhor produto que já comprei', '2020-10-22 00:00:00.000000', 5, 3, 20);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (2, 'bem ok, pensei que era melhor', '2020-10-11 00:00:00.000000', 3, 3, 55);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (3, 'muito ruim, não funciona nada,veio de forma deplorável', '2020-09-15 00:00:00.000000', 1, 3, 3);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (5, 'melhor que isso, apenas todos os outros, simplesmente horrível', '2020-09-08 00:00:00.000000', 2, 4, 86);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (6, 'ok', '2020-10-11 00:00:00.000000', 4, 4, 109);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (7, 'recomendo', '2020-10-10 00:00:00.000000', 5, 5, 109);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (8, 'recomendadíssimo', '2020-09-02 00:00:00.000000', 4, 6, 109);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (9, 'muito bom como o previsto', '2020-09-06 00:00:00.000000', 4, 6, 87);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (10, 'não é bom, n recomendo!', '2020-10-08 00:00:00.000000', 3, 7, 20);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (11, 'mediano apenas', '2020-10-10 00:00:00.000000', 3, 7, 78);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (12, 'melhor que a maioria, recomendo', '2020-08-22 00:00:00.000000', 4, 8, 102);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (13, 'acima das minhas expectativas', '2020-09-11 00:00:00.000000', 5, 8, 20);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (14, 'melhor produto', '2020-10-10 00:00:00.000000', 5, 9, 120);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (15, 'mediano, muito mediano', '2020-10-13 00:00:00.000000', 5, 9, 20);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (16, 'isso valeu meu dinheiro', '2020-10-12 00:00:00.000000', 5, 9, 2);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (17, 'recomendo', '2020-10-10 00:00:00.000000', 4, 9, 98);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (18, 'valeu meu investimento', '2020-10-10 00:00:00.000000', 4, 10, 80);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (19, 'tem muita coisa melhor, n recomendo', '2020-10-22 00:00:00.000000', 2, 10, 109);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (20, 'menos interessante do que pensei ):', '2020-10-26 00:00:00.000000', 2, 10, 38);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (21, 'sem comentários', '2020-10-23 00:00:00.000000', 1, 11, 100);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (22, 'minha nota fala por si só', '2020-10-10 00:00:00.000000', 1, 11, 110);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (23, 'bom', '2020-10-10 00:00:00.000000', 3, 11, 20);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (24, 'bem ok viu', '2020-10-10 00:00:00.000000', 3, 11, 58);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (25, 'aaaaaaah muito ruim', '2020-10-19 00:00:00.000000', 1, 12, 100);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (26, 'tudo isso!', '2020-10-10 00:00:00.000000', 4, 12, 109);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (27, 'quem é que vai ser louco de comprar isso?', '2020-10-10 00:00:00.000000', 3, 12, 119);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (28, 'recomendo', '2020-10-09 00:00:00.000000', 4, 12, 92);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (29, 'bem mediano', '2020-10-14 00:00:00.000000', 3, 12, 9);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (30, 'era melhor ter ido ver o pelé', '2020-10-18 00:00:00.000000', 2, 13, 103);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (31, 'RECOMENDO!', '2020-10-20 00:00:00.000000', 5, 13, 44);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (32, 'MUITO RUIM, PÉSSIMO, NEM FUNCIONA SA ****', '2020-10-01 00:00:00.000000', 5, 13, 108);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (33, 'beleza, funcionou que uma maravilha', '2020-10-10 00:00:00.000000', 4, 14, 109);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (34, 'D:', '2020-09-10 00:00:00.000000', 3, 14, 108);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (35, 'isso não valeu meu investimento', '2020-10-10 00:00:00.000000', 2, 14, 30);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (36, 'melhor que muitos, recomendo', '2020-10-10 00:00:00.000000', 4, 14, 122);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (37, 'dale que é bom', '2020-10-15 00:00:00.000000', 4, 15, 25);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (38, 'demorou chegar mas valeu a espera, recomendo a todos', '2020-10-10 00:00:00.000000', 4, 15, 8);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (39, 'só faltou ser bom de resto ok', '2020-10-10 00:00:00.000000', 3, 15, 120);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (40, 'bem ok', '2020-10-10 00:00:00.000000', 3, 16, 120);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (41, 'TOPEIRA 2', '2020-11-03 00:00:00.000000', 3, 1, 62);
INSERT INTO public.avaliacao (id, comentario, datapostado, nota, pessoa_id, produto_id) VALUES (42, 'GTX 1660 TOPEIRONA!!!!! NAO SUPERAQUECE!!!!!!!', '2020-11-03 00:00:00.000000', 4, 1, 61);