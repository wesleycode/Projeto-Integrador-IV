CREATE TABLE MARCAPRODUTO
(
    ID   BIGSERIAL NOT NULL
        CONSTRAINT MARCAPRODUTO_PKEY
            PRIMARY KEY,
    NOME VARCHAR(255)
);

ALTER TABLE MARCAPRODUTO
    OWNER TO POSTGRES;

INSERT INTO public.marcaproduto (id, nome) VALUES (1, 'HYPER X');
INSERT INTO public.marcaproduto (id, nome) VALUES (2, 'XPG');
INSERT INTO public.marcaproduto (id, nome) VALUES (3, 'CORSAIR');
INSERT INTO public.marcaproduto (id, nome) VALUES (4, 'HP');
INSERT INTO public.marcaproduto (id, nome) VALUES (5, 'KINGSTON');
INSERT INTO public.marcaproduto (id, nome) VALUES (6, 'INTEL');
INSERT INTO public.marcaproduto (id, nome) VALUES (7, 'SEAGATE');
INSERT INTO public.marcaproduto (id, nome) VALUES (8, 'WD');
INSERT INTO public.marcaproduto (id, nome) VALUES (9, 'TOMAHAWK');
INSERT INTO public.marcaproduto (id, nome) VALUES (10, 'FORTREK');
INSERT INTO public.marcaproduto (id, nome) VALUES (11, 'EVGA');
INSERT INTO public.marcaproduto (id, nome) VALUES (12, 'ONE POWER');
INSERT INTO public.marcaproduto (id, nome) VALUES (13, 'RAPTOR');
INSERT INTO public.marcaproduto (id, nome) VALUES (14, 'COOLER MASTER');
INSERT INTO public.marcaproduto (id, nome) VALUES (15, 'GAMDIAS');
INSERT INTO public.marcaproduto (id, nome) VALUES (16, 'RISE MODE');
INSERT INTO public.marcaproduto (id, nome) VALUES (17, 'DEEPCOOL');
INSERT INTO public.marcaproduto (id, nome) VALUES (18, 'DARKFLASH');
INSERT INTO public.marcaproduto (id, nome) VALUES (19, 'BLUECASE');
INSERT INTO public.marcaproduto (id, nome) VALUES (20, 'AOC');
INSERT INTO public.marcaproduto (id, nome) VALUES (21, 'PCTOP');
INSERT INTO public.marcaproduto (id, nome) VALUES (22, 'LG');
INSERT INTO public.marcaproduto (id, nome) VALUES (23, 'ACER');
INSERT INTO public.marcaproduto (id, nome) VALUES (24, 'AGON');
INSERT INTO public.marcaproduto (id, nome) VALUES (25, 'SAMSUNG');
INSERT INTO public.marcaproduto (id, nome) VALUES (26, 'ASUS');
INSERT INTO public.marcaproduto (id, nome) VALUES (27, 'CREATIVE');
INSERT INTO public.marcaproduto (id, nome) VALUES (28, 'GV');
INSERT INTO public.marcaproduto (id, nome) VALUES (29, 'GIGABYTE');
INSERT INTO public.marcaproduto (id, nome) VALUES (30, 'GALAX');
INSERT INTO public.marcaproduto (id, nome) VALUES (31, 'MSI');
INSERT INTO public.marcaproduto (id, nome) VALUES (32, 'POWER COLOR');
INSERT INTO public.marcaproduto (id, nome) VALUES (33, 'AORUS');
INSERT INTO public.marcaproduto (id, nome) VALUES (34, 'NORTON');
INSERT INTO public.marcaproduto (id, nome) VALUES (35, 'KASPERSKY');
INSERT INTO public.marcaproduto (id, nome) VALUES (36, 'PNY');
INSERT INTO public.marcaproduto (id, nome) VALUES (37, 'LENOVO');
INSERT INTO public.marcaproduto (id, nome) VALUES (38, 'VAIO');