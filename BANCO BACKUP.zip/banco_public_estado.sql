CREATE TABLE ESTADO
(
    ID   BIGSERIAL NOT NULL
        CONSTRAINT ESTADO_PKEY
            PRIMARY KEY,
    NOME VARCHAR(255),
    UF   VARCHAR(255)
);

ALTER TABLE ESTADO
    OWNER TO POSTGRES;

INSERT INTO public.estado (id, nome, uf) VALUES (1, 'Acre', 'AC');
INSERT INTO public.estado (id, nome, uf) VALUES (2, 'Alagoas', 'AL');
INSERT INTO public.estado (id, nome, uf) VALUES (3, 'Amazonas', 'AM');
INSERT INTO public.estado (id, nome, uf) VALUES (4, 'Amapá', 'AP');
INSERT INTO public.estado (id, nome, uf) VALUES (5, 'Bahia', 'BA');
INSERT INTO public.estado (id, nome, uf) VALUES (6, 'Ceará', 'CE');
INSERT INTO public.estado (id, nome, uf) VALUES (7, 'Distrito Federal', 'DF');
INSERT INTO public.estado (id, nome, uf) VALUES (8, 'Espírito Santo', 'ES');
INSERT INTO public.estado (id, nome, uf) VALUES (9, 'Goiás', 'GO');
INSERT INTO public.estado (id, nome, uf) VALUES (10, 'Maranhão', 'MA');
INSERT INTO public.estado (id, nome, uf) VALUES (11, 'Minas Gerais', 'MG');
INSERT INTO public.estado (id, nome, uf) VALUES (12, 'Mato Grosso do Sul', 'MS');
INSERT INTO public.estado (id, nome, uf) VALUES (13, 'Mato Grosso', 'MT');
INSERT INTO public.estado (id, nome, uf) VALUES (14, 'Pará', 'PA');
INSERT INTO public.estado (id, nome, uf) VALUES (15, 'Paraíba', 'PB');
INSERT INTO public.estado (id, nome, uf) VALUES (16, 'Pernambuco', 'PE');
INSERT INTO public.estado (id, nome, uf) VALUES (17, 'Piauí', 'PI');
INSERT INTO public.estado (id, nome, uf) VALUES (18, 'Paraná', 'PR');
INSERT INTO public.estado (id, nome, uf) VALUES (19, 'Rio de Janeiro', 'RJ');
INSERT INTO public.estado (id, nome, uf) VALUES (20, 'Rio Grande do Norte', 'RN');
INSERT INTO public.estado (id, nome, uf) VALUES (21, 'Rondônia', 'RO');
INSERT INTO public.estado (id, nome, uf) VALUES (22, 'Roraima', 'RR');
INSERT INTO public.estado (id, nome, uf) VALUES (23, 'Rio Grande do Sul', 'RS');
INSERT INTO public.estado (id, nome, uf) VALUES (24, 'Santa Catarina', 'SC');
INSERT INTO public.estado (id, nome, uf) VALUES (25, 'Sergipe', 'SE');
INSERT INTO public.estado (id, nome, uf) VALUES (26, 'São Paulo', 'SP');
INSERT INTO public.estado (id, nome, uf) VALUES (27, 'Tocantins', 'TO');