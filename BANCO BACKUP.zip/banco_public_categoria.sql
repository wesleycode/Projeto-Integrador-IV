CREATE TABLE CATEGORIA
(
    ID        BIGSERIAL NOT NULL
        CONSTRAINT CATEGORIA_PKEY
            PRIMARY KEY,
    CATEGORIA VARCHAR(255)
);

ALTER TABLE CATEGORIA
    OWNER TO POSTGRES;

INSERT INTO public.categoria (id, categoria) VALUES (1, 'Memoria Ram');
INSERT INTO public.categoria (id, categoria) VALUES (2, 'HDs');
INSERT INTO public.categoria (id, categoria) VALUES (3, 'SSDs');
INSERT INTO public.categoria (id, categoria) VALUES (4, 'Processadores');
INSERT INTO public.categoria (id, categoria) VALUES (8, 'Coolers');
INSERT INTO public.categoria (id, categoria) VALUES (9, 'Monitores');
INSERT INTO public.categoria (id, categoria) VALUES (10, 'Notebooks');
INSERT INTO public.categoria (id, categoria) VALUES (11, 'Softwares');
INSERT INTO public.categoria (id, categoria) VALUES (12, 'Periféricos');
INSERT INTO public.categoria (id, categoria) VALUES (13, 'Fontes');
INSERT INTO public.categoria (id, categoria) VALUES (7, 'Placa Mãe');
INSERT INTO public.categoria (id, categoria) VALUES (6, 'Placa de Som');
INSERT INTO public.categoria (id, categoria) VALUES (5, 'Placa de Video');