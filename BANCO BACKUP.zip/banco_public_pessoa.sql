CREATE TABLE PESSOA
(
    ID             BIGSERIAL NOT NULL
        CONSTRAINT PESSOA_PKEY
            PRIMARY KEY,
    ATIVO          BOOLEAN   NOT NULL,
    CPF            VARCHAR(255),
    DATANASCIMENTO DATE,
    EMAIL          VARCHAR(255),
    NOME           VARCHAR(255),
    SENHA          VARCHAR(255),
    TELEFONE       VARCHAR(255),
    TIPOUSUARIO    INTEGER   NOT NULL,
    ENDERECO_ID    BIGINT
        CONSTRAINT FKETLGGXAGE7IXU17GAF2NX53IJ
            REFERENCES ENDERECO
);

ALTER TABLE PESSOA
    OWNER TO POSTGRES;

INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (2, true, '014.952.890-60', '2001-02-12', 'felipefillus10@gmail.com', 'Felipe fillus', 'aaa', '(41) 4444-4444', 3, 2);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (3, true, '575.013.220-07', '2001-02-12', 'lucasmateus@gmail.com', 'Lucas Matheus', 'aaa', '(41) 4444-4445', 3, 3);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (4, true, '019.096.120-14', '2001-02-12', 'jonathana@gmail.com', 'jonathan', 'aaa', '(41) 4444-4446', 3, 4);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (5, true, '746.722.490-77', '2001-02-12', 'matedarcin@gmail.com', 'Mateus Garcin', 'aaa', '(41) 4444-4446', 3, 5);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (6, true, '757.075.110-83', '2001-02-12', 'luanagonzaga@gmail.com', 'Luana Gonzaga', 'aaa', '(41) 4444-4447', 3, 6);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (7, true, '638.264.340-80', '2001-02-12', 'mariasouza@gmail.com', 'Maria de souza', 'aaa', '(41) 4444-4448', 3, 7);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (8, true, '753.618.120-56', '2001-02-12', 'Alex12@gmail.com', 'Alex', 'aaa', '(41) 4444-4449', 3, 8);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (9, true, '302.817.770-63', '2001-02-12', 'robertorocha@gmail.com', 'Roberto Rocha', 'aaa', '(41) 4444-4450', 3, 9);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (10, true, '700.911.770-57', '2001-02-12', 'carlasir@gmail.com', 'Carla Silveira', 'aaa', '(41) 4444-4451', 3, 10);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (11, true, '563.004.750-77', '2001-02-12', 'felipesouza@gmail.com', 'Felipe de souza', 'aaa', '(41) 4444-4452', 3, 11);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (12, true, '128.083.630-01', '2001-02-12', 'gabrielandrade@gmail.com', 'Gabriel de andrade', 'aaa', '(41) 4444-4453', 3, 12);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (13, true, '891.132.170-20', '2001-02-12', 'miltonmilton@gmail.com', 'Milton o Milton', 'aaa', '(41) 4444-4454', 3, 13);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (14, true, '890.934.310-99', '2001-02-12', 'daniel10@gmail.com', 'Daniel cordel', 'aaa', '(41) 4444-4455', 3, 14);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (15, true, '384.485.350-22', '2001-02-12', 'daiane@gmail.com', 'Daiane', 'aaa', '(41) 4444-4456', 3, 15);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (16, true, '735.903.210-59', '2001-02-12', 'janaina1@gmail.com', 'Janaina', 'aaa', '(41) 4444-4457', 3, 16);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (17, true, '738.415.250-08', '2001-02-12', 'rodrigocorsair@gmail.com', 'Rodrigo Cosair', 'aaa', '(41) 4444-4458', 3, 17);
INSERT INTO public.pessoa (id, ativo, cpf, datanascimento, email, nome, senha, telefone, tipousuario, endereco_id) VALUES (1, true, '006.001.590-00', '1998-05-24', 'kako.araujo.24@gmail.com', 'WESLEY DE ARAUJO EVANGELISTA', '00000000', '(41) 0000-0000', 1, 1);